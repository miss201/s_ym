﻿<?

  
include('../system/inc.php');
include('./admin_config.php');
include('./check.php');
$dh = 'sys';

if(isset($_POST['提交'])){
	$_data['s_mintxje'] = $_POST['s_mintxje'];
	$_data['s_maxtxje'] = $_POST['s_maxtxje'];
	$_data['s_maxtxcs'] = $_POST['s_maxtxcs'];
	$_data['s_txsxf'] = $_POST['s_txsxf'];
	$_data['s_api'] = $_POST['s_api'];
	$_data['s_name'] = $_POST['s_name'];
	$_data['s_sname'] = $_POST['s_sname'];
	$_data['s_content'] = $_POST['s_content'];
	$_data['s_domain'] = trim($_POST['s_domain']);
	$_data['s_domains'] = trim($_POST['s_domains']);
	$_data['s_hezi'] = $_POST['s_hezi'];
	$_data['s_suiji'] = $_POST['s_suiji'];
	$_data['s_pc'] = $_POST['s_pc'];
	$_data['s_userupload'] = $_POST['s_userupload'];
	$_data['s_fangfengurl'] = $_POST['s_fangfengurl'];
	$_data['s_morenticheng'] = $_POST['s_morenticheng'];
	$_data['s_tichengset'] = $_POST['s_tichengset'];
	$_data['s_dingshi'] = $_POST['s_dingshi'];
	$_data['s_notice'] = $_POST['s_notice'];
 	
  	$sql = 'update '.flag.'system set '.arrtoupdate($_data).' where id = 1';
	if(mysql_query($sql)){
		alert_href('系统设置修改成功!','sys.php');
	}else{
		alert_back('修改失败!');
	}
}


 ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
 	<link rel="shortcut icon" href="/statics/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="/statics/layui/css/layui.css">
	<link rel="stylesheet" type="text/css" href="/statics/css/font.css">
	<link rel="stylesheet" type="text/css" href="/statics/css/ui.css">
	<link rel="stylesheet" type="text/css" href="/statics/css/public.css">
	<link rel="stylesheet" type="text/css" href="/statics/Font-Awesome/css/font-awesome.css">
	<script type="text/javascript" src="/statics/js/jquery.min.js"></script>
 	<script type="text/javascript" src="/statics/js/public.js"></script>
	<script type="text/javascript" src="/statics/layui/layui.js"></script>
	<script type="text/javascript" src="/statics/js/global.js"></script>
	
 <link rel="stylesheet" href="../editor/themes/default/default.css" />
  <script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="../ui/ui.js"></script>
<script type="text/javascript" src="../js/admin.js"></script>
<script charset="utf-8" type="text/javascript" src="../editor/kindeditor.js"></script>

 <script type="text/javascript">
KindEditor.ready(function(K) {
	K.create('#s_notice');
	var editor = K.editor();
	K('#upload-image').click(function() {
		editor.loadPlugin('image', function() {
			editor.plugin.imageDialog({
			imageUrl : K('#site_logo').val(),
			clickFn : function(url, title, width, height, border, align) {
				K('#site_logo').val(url);
				editor.hideDialog();
				}
			});
		});
	});
	K('#slideshow').click(function() {
		editor.loadPlugin('multiimage', function() {
			editor.plugin.multiImageDialog({
				clickFn : function(urlList) {
					var tem_val = '';
					var tem_s = '';
					K.each(urlList, function(i, data) {
						tem_val = tem_val + tem_s + data.url;
						tem_s = '|';
					});
					K('#d_slideshow').val(tem_val);
					editor.hideDialog();
				}
			});
		});
	});
	K('#download1').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#download_url1').val(),
				clickFn : function(url, title) {
					K('#download_url1').val(url);
					editor.hideDialog();
				}
			});
			
 		});
	});
	
	
	K('#download2').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#download_url2').val(),
				clickFn : function(url, title) {
					K('#download_url2').val(url);
					editor.hideDialog();
				}
			});
			
 		});
	});
	
	
		K('#download3').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#download_url3').val(),
				clickFn : function(url, title) {
					K('#download_url3').val(url);
					editor.hideDialog();
				}
			});
			
 		});
	});
	
	
		K('#download4').click(function() {
		editor.loadPlugin('insertfile', function() {
			editor.plugin.fileDialog({
				fileUrl : K('#download_url4').val(),
				clickFn : function(url, title) {
					K('#download_url4').val(url);
					editor.hideDialog();
				}
			});
			
 		});
	});
	
	
});
</script>	
	<title>基础设置</title>
</head>
<body>
	<div id="main-container">
		<?
		
		include('head.php');
 ?>
<div class="sidebar">
	<div class="sidebar_tool"><i class="icon-dedent"></i></div>
	 
	 
	 	<?
		
		include('left.php');
 ?>
 
</div>
 
		<div class="main">
			<div class="notice">您当前的位置：<a href="/">首页</a> &gt; <a href="" >常用菜单</a> &gt; <a href="" >基础设置</a></div>
			<div class="main_content">
				<div class="title">
					<span>基础设置</span>
				</div>
				<form  class="layui-form layui-form-pane" id="formrec" method="post" role="form">
				
				
					
                    
                            
                    <div class="layui-form-item">
			            <label class="layui-form-label">电脑访问</label>
			            <div class="layui-input-inline">

      <select name="s_pc"   data-val="true" lay-filter="pid"  lay-verify="required">
  			                <option <?  if ($site_pc =='1') { echo "selected";}?>  value="1"  >允许</option>
			                <option  <?  if ($site_pc =='0') { echo "selected";}?> value="0"  >不允许</option>
 								 
						  </select>
						  
						  			            </div>
                       </div>
                       
                                   
                    <div class="layui-form-item">
			            <label class="layui-form-label">代理上传</label>
			            <div class="layui-input-inline">

      <select name="s_userupload"   data-val="true" lay-filter="pid"  lay-verify="required">
  			                <option <?  if ($site_userupload =='1') { echo "selected";}?>  value="1"  >允许</option>
			                <option  <?  if ($site_userupload =='0') { echo "selected";}?> value="0"  >不允许</option>
 								 
						  </select>
						  
						  			            </div>
                       </div>
                       
                    
                    <div class="layui-form-item">
			            <label class="layui-form-label">盒子推广</label>
			            <div class="layui-input-inline">

      <select name="s_hezi"   data-val="true" lay-filter="pid"  lay-verify="required">
  			                <option <?  if ($site_hezi =='1') { echo "selected";}?>  value="1"  >启用</option>
			                <option  <?  if ($site_hezi =='0') { echo "selected";}?> value="0"  >关闭</option>
 								 
						  </select>
						  
						  			            </div>
			        </div><div class="layui-form-item">
			            <label class="layui-form-label">随机打赏数</label>
			            <div class="layui-input-inline">

      <select name="s_suiji"   data-val="true" lay-filter="pid"  lay-verify="required">
  			                <option <?  if ($site_suiji =='1') { echo "selected";}?>  value="1"  >启用</option>
			                <option  <?  if ($site_suiji =='0') { echo "selected";}?> value="0"  >关闭</option>
 								 
						  </select>
						  
						  			            </div>
			        </div>


					 
				 <div class="layui-form-item">
			            <label class="layui-form-label">网站标题</label>
			            <div class="layui-input-inline">
			                <input name="s_name" type="text" class="layui-input"  value="<? echo $site_name?>" placeholder="请输入网站标题">
			            </div>
			        </div>
					
				  <div class="layui-form-item">
			            <label class="layui-form-label">网站副标题</label>
			            <div class="layui-input-inline">
			                <input name="s_sname" type="text" class="layui-input"  value="<? echo $site_sname?>" placeholder="请输入网站副标题">
			            </div>
			        </div>
					
                    
						  <div class="layui-form-item">
			            <label class="layui-form-label">平台公告</label>
			            <div class="layui-input-inline">
			                <textarea name="s_notice" id="s_notice" class="layui-input" placeholder="请输入平台公告"><? echo $site_notice?></textarea>
			            </div>
			        </div>
					
                    
					
						  <div class="layui-form-item">
			            <label class="layui-form-label">版权信息</label>
			            <div class="layui-input-inline">
			                <textarea name="s_content" class="layui-input" placeholder="请输入版权信息"><? echo $site_content?></textarea>
			            </div>
			        </div>
					
					
					
					<div class="layui-form-item">
			            <label class="layui-form-label">主域名</label>
			            <div class="layui-input-inline">
			                <input name="s_domain" type="text" class="layui-input" id="domain" value="<? echo $site_domain?>" placeholder="请输入主域名">
			            </div>
			        </div>
					
					
					
					
					<div class="layui-form-item">
			            <label class="layui-form-label">落地域名随机调用</label>
			            <div class="layui-input-inline">

      <select name="s_domains"   data-val="true" lay-filter="pid"  lay-verify="required">
			                <option value="1" <?  if ($site_domains =='1') { echo "selected";}?>  >开启</option>
			                <option value="0" <?  if ($site_domains =='0') { echo "selected";}?>  >关闭</option>
									 
						  </select>
						  
						  			            </div>
			        </div>
					
                    
                    		
					<div class="layui-form-item">
			            <label class="layui-form-label">防封尾缀</label>
			            <div class="layui-input-inline">

         			                <input name="s_fangfengurl" type="text" class="layui-input"   value="<? echo $site_fangfengurl?>" placeholder="仿封尾缀"> 

						  			            </div>
			        </div>
					
					
					
						
                        <div class="title_bar mb20">
						代理提成设置
					</div>

					<div class="layui-form-item">
			            <label class="layui-form-label">默认提成</label>
			            <div class="layui-input-inline">

    			                <input name="s_morenticheng" type="text" class="layui-input"   value="<? echo $site_morenticheng?>" placeholder="代理默认提成"> 
						  			            </div>
			        </div>
					
                    
                                 
                    <div class="layui-form-item">
			            <label class="layui-form-label">代理修改</label>
			            <div class="layui-input-inline">

      <select name="s_tichengset"   data-val="true" lay-filter="pid"  lay-verify="required">
 			                <option  <?  if ($site_setticheng =='0') { echo "selected";}?> value="0"  >不允许</option>
 								 
						  </select>
						  
						  			            </div>
                       </div>
                       
                       
                       
                    
                    
                    <div class="title_bar mb20">
						提现设置
					</div>

					<div class="layui-form-item">
			            <label class="layui-form-label">最低提现金额</label>
			            <div class="layui-input-inline">

    			                <input name="s_mintxje" type="text" class="layui-input"   value="<? echo $site_mintxje?>" placeholder="最低提现金额"> 
						  			            </div>
			        </div>
					
					
									<div class="layui-form-item">
			            <label class="layui-form-label">最高提现金额</label>
			            <div class="layui-input-inline">

    			                <input name="s_maxtxje" type="text" class="layui-input"   value="<? echo $site_maxtxje?>" placeholder="最高提现金额"> 
						  			            </div>
			        </div>


	<div class="layui-form-item">
			            <label class="layui-form-label">每日最多提现次数</label>
			            <div class="layui-input-inline">

    			                <input name="s_maxtxcs" type="text" class="layui-input"   value="<? echo $site_maxtxcs?>" placeholder="每日最多提现次数"> 
						  			            </div>
			        </div>



	<div class="layui-form-item">
			            <label class="layui-form-label">提现手续费</label>
			            <div class="layui-input-inline">

    			                <input name="s_txsxf" type="text" class="layui-input"   value="<? echo $site_txsxf?>" placeholder="提现手续费%"> 
						  			            </div>
			        </div>

					
			 
			 
			 
			 
						<div class="title_bar mb20">
						短网址接口
					</div>


	
					<div class="layui-form-item">
			            <label class="layui-form-label">短网址接口</label>
			            <div class="layui-input-inline">

      <select name="s_api"   data-val="true" lay-filter="pid"  lay-verify="required">
			                <option value=""  >请选择短网址接口</option>
			                <option value="0" <?  if ($site_dwz =='0') { echo "selected";}?>   >不设置</option>
			                <option <?  if ($site_dwz =='tcn') { echo "selected";}?>  value="tcn"  >t.cn</option>
			                <option  <?  if ($site_dwz =='urlcn') { echo "selected";}?> value="urlcn"  >url.cn</option>
 								 
						  </select>
						  
						  			            </div>
			        </div>






						<div class="title_bar mb20">
						短网址接口
					</div>


	
				 
	<div class="layui-form-item">
			            <label class="layui-form-label">试看时间</label>
			            <div class="layui-input-inline">

    			                <input name="s_dingshi" type="text" class="layui-input"   value="<? echo $site_dingshi?>" placeholder="请输入试看时间"> 
						  			            </div>
			        </div>

					
			 


 
					
					<div class="layui-form-item" style="display:none">
	                    <label class="layui-form-label">引导页</label>
	                    <div class="layui-input-inline">
	                        <input type="checkbox"  name="site_guide" lay-skin="switch" lay-filter="switchTest">
	                    </div>
	                </div>

	              


					<div class="layui-form-item">
	                    <label class="layui-form-label"></label>
	                    <div class="layui-input-inline">
						
						<input name="提交" class="btn"  type="submit" value="提交">
 	                    </div>
			        </div>
				</form>

			</div>
		</div>
	</div>
<!-- <link rel="stylesheet" href="/statics/css/webuploader.css">
<script type="text/javascript" src="/statics/js/webuploader.js"></script> -->
	<?
 	include('f.php');
 
?>
<script>
layui.use(['form','common','upload'], function(){
        var $ = layui.jquery;
        $form = $('form');
        var form = layui.form(),layer = layui.layer,common=layui.common;

	 
        layui.upload({
            url: "/index.php/admin/upload/upload/file/file" //上传接口
            ,before: function(input){
                console.log('图片上传中');
            }
            ,title:'上传图片'
            ,elem: '#upload-image' //指定原始元素，默认直接查找class="layui-upload-file"
            ,method: 'post' //上传接口的http类型
            ,ext: 'jpg|png|gif'
            ,type:'images'
            ,success: function(data){ //上传成功后的回调
             
            }
        });

      

		/*$('#picture_show').on('mouseenter','.picture_item',function(){
				$(this).find('.picture_go_up').show();
				$(this).find('.picture_del').show();
			}).on('mouseleave','.picture_item',function(){
				$(this).find('.picture_go_up').hide();
				$(this).find('.picture_del').hide();
			}
		); 

	    $('#picture_show').on('click','.picture_go_up',function () {
	        var parent = $(this).parent();
	        if (parent.index() == 0){
	        }else{
	        	parent.prev().before(parent);
	        	$(this).hide();
	        	parent.find('.picture_del').hide();
	        }
	        updateimg('imgval', 'imglist');
	    });

	    $('#picture_show').on('click','.picture_del',function () {
	        var img = $(this).next().val();//下个元素input的值 
			$(this).parent().remove();////移除父元素
			updateimg('imgval', 'imglist');
			return;     
	    });*/

        //监听提交
        form.on('submit(save)', function(data){

            var sub = true;
            var url = $(this).data('href');
            if(url){
                if(sub){
                    $.ajax({
                        url: url,
                        type: 'post',
                        dataType: 'json',
                        data: data.field,
                        success: function (info) {
                            if (info.code == 1) {
                                common.layerAlertSHref(info.msg, '提示', "/index.php/admin/system/basic");
                            }
                            else {
                                common.layerAlertE(info.msg, '提示');
                            }
                        },
                        beforeSend: function () {
                            $(data.elem).attr("disabled", "true").text("提交中...");
                        },
                        error: function (XMLHttpRequest, textStatus, errorThrown) {
                            common.layerAlertE(textStatus, '提示');
                        }
                    });
                }
            }else{
                common.layerAlertE('链接错误！', '提示');
            }
            return false;
        });

    });
/*function updateimg(node,name){
	var num = $('.'+node);
	var valstr = "";
	for(i=0;i<num.length;i++)
	{
		valstr = valstr+num.eq(i).val()+"***";
	}
	$("#"+name).val(valstr);
}*/
</script>
</body>
</html>