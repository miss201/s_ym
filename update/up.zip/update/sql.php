<?
include('../system/inc.php');
$sql='ALTER TABLE `'.flag.'_system` ADD `s_notice` LONGTEXT NULL AFTER `s_dingshi`';
//mysql_query($sql);
  
				mysql_query($sql);	
 					



?>