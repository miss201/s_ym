
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>更多信息</title>
<meta content="width=device-width,initial-scale=1,user-scalable=no" name="viewport">
<style>
*{margin:0;padding:0;}
body{font-size:14px;font-family:"微软雅黑";}
a{text-decoration:none;}
li{list-style:none;}
input{border:none;background:none;outline:none;}
.head{width:80%;margin-left:10%;}
.head .p1{font-weight:bold;font-size:15px;height:40px;line-height:40px;border-bottom:1px solid #ccc;text-align:center;}
.head .p2{color:#8f8f8f;font-size:12px;margin-top:10px;}
.head .p3{color:#8f8f8f;font-size:12px;margin-top:10px;}
.button{height:40px;line-height:40px;text-align:center;background:#03bd00;border-radius:10px;margin-top:20px;}
</style>
</head>
<body>
<div class="head">
<p class="p1">更多潜在的色情内容</p>
<p class="p2">你好，你将要访问的网址被用户投诉包含"色情内容"。腾讯安全中心手机管家经过云网址检测后，认为该网址有较高风险，已停止其在微信内访问。</p>
<p class="p3">如果你确认该网页不含色情内容，可以进行反馈</p>
<div  class="button"><a href="https://weixin110.qq.com/security/readtemplate?t=webpage_appeal/w_form&url=http%3A%2F%2Fwww.baidu.com%2Fql27&blocktype=25#wechat_redirect" style="color:#fff;display:block;width:100%;height:40px;">我要反馈</a></div>
</div>
</body>
</html>