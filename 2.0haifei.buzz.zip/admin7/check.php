<?php
   echo admin_check  ($_SESSION['admin_check']) ;
 	
	if ($wid!=0)
	{		alert_url('404');};
	
	?>