<style>
body
  {
    padding-top:0;
  }
  .main
  {
  	margin: 0;
    width: 100%;
  }
</style>
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="display:none;">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="#"><span>云赏后台管理控制台</span><?=$a_name?></a>
				<ul class="user-menu">
					<li class="dropdown pull-right">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> User <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="admin.php"><span class="glyphicon glyphicon-user"></span> 修改密码</a></li>
 							<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> 安全退出</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>