﻿{"code":1,"data":null,"msg":"退出成功"}

<?

 include('../system/inc.php');
 include('./admin_config.php');
 
 $_SESSION['admin_check'] ='';
// echo admin_logout('');
?>
 
 