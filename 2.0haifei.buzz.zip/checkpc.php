<?

 if ($site_pc==0 && iswap() == 0 )
 {die ('');}

  

?>