 
<div class="nav_left">
		<ul>
  						
						
  

 
						<li><a href="kouliang.php" class="<? if ($dh =='kouliang') echo "v-link-active";?>"><i class="fa fa-sitemap"></i>扣量管理</a></li>

						<li><a href="kouliangorder.php" class="<? if ($dh =='kouliangorder') echo "v-link-active";?>"><i class="fa fa-tag"></i>扣量订单</a></li>

						 
					</ul>
	</div>