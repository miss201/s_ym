<div class="header">
	<div class="logo fl"><a href="javascript:;"><i class="icon icon-yun"></i></a></div>
	<div class="head_name fl"><a href="admin_index.php">管理控制台</a></div>
	<div class="nav fl">
		<ul class="clearfix">

 						
						
							 

 		</ul>
	</div>
	<div class="head_tool fr">
		<a href="/" target="_blank" title="站点首页"><i class="icon-home"></i></a>
		
		<a class="doLoginOut" title="安全退出" data-type="doLoginOut" data-href="logout.php" data-rturl="index.php"><i class="icon-out"></i></a>
		
 		
 	</div>
</div>