<?
if ($_SESSION['member_id']=='')
{alert_href('请先登录','/login.php');}

?>