<?php	require_once(dirname(__FILE__).'/inc/config.inc.php');

/*
**************************
(C)2018
uozhifu
**************************
*/

//初始化变量
$b_url = 'templates/html/default.html';
require_once($b_url);

?>
