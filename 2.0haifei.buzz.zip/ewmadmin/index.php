<?php	require_once(dirname(__FILE__).'/inc/config.inc.php');

/*
**************************
(C)2018
uozhifu
**************************
*/

header('location:default.php');
exit();

?>
