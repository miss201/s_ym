<?php	if(!defined('IN_UOZHIFU')) exit('Request Error!');

$ewmjiexiurl = '../ewmimages/';
$cfg_webswitch = 'Y';
$cfg_webname = '管理系统';
$ewmadminurl = 'ewmadmin';
$ldpayoff = '0';
$accounttype = '1';
$renyitype = '1';
$keytype = '0';
$httptype = '0';
$payok2018type = '1';
$ewmjiexi = '1';
$aliewmok = '0';
$wxqqewmok = '1';
$bdewmtype = '2';
$ewmposttype = '3';
$xianail = '0';
$xiancft = '0';
$xianwx = '1';
$cfg_ldtimeout = '10';
$cfg_ddtimeout = '180';
$cfg_mysql_type = 'mysqli';
$cfg_pagenum = '10';
$cfg_timezone = '8';
$cfg_remind = '付款时请支付下方付款金额<br>一分不能多一分不能少，否则无法跳转!!!';
$cfg_remindok = 'Y';
$cfg_js = 'N';
$cfg_diserror = 'N';

?>